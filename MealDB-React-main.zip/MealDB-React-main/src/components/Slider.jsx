export default function Slider() {
    return (
        <div className="w-100 position-relative sliderImageContainer">
            <img className="w-100 " src="/images/fav.jpg" />
            <h3 className=" bgOverLay m-0 position-absolute top-0 bottom-0 right-0 lefft-0 d-flex justify-content-center align-items-center w-100 text-white ">
                MealDB With React
            </h3>
        </div>
    )
}